
require('./ideal.js')
require('./ideal_plus.js')
